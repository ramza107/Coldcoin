ReplayFace Mini Client v3.1
===========================
1. Install Node.js LTS, restart PC
2. RUN.bat (keep window open)
3. Browser http://127.0.0.1:17321/
4. Connect profile — sync goes through companion OpenDota proxy

If Connect hangs: restart RUN.bat, wait for "Ready", then Connect again.
