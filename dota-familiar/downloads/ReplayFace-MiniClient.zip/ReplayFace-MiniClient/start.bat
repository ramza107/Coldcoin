@echo off
cd /d "%~dp0"
if not exist node_modules (
  echo First run: npm install...
  call npm install
)
call mini-client\start.bat
