@echo off
chcp 65001 >nul
cd /d "%~dp0"
title ReplayFace Mini Client v2
echo.
echo  ReplayFace Mini Client v2
echo  ========================
echo.

if not exist "dist\index.html" (
  echo ERROR: папка dist не найдена. Скачай zip заново.
  pause
  exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: поставь Node.js LTS — https://nodejs.org/
  pause
  exit /b 1
)

echo Запуск http://127.0.0.1:17321/
echo Не закрывай это окно пока играешь.
echo.
start "" "http://127.0.0.1:17321/"
node companion\server.mjs
if errorlevel 1 pause
