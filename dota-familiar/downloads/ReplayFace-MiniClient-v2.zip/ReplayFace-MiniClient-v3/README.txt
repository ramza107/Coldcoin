ReplayFace Mini Client v3
=========================

1. Install Node.js LTS: https://nodejs.org/  then restart PC
2. Unzip this folder
3. Double-click CHECK.bat  (shows what is missing)
4. Double-click RUN.bat    (window must stay open)
5. Browser -> http://127.0.0.1:17321/

If the window closes immediately:
  - run CHECK.bat
  - open companion-run.log
  - make sure Node is installed

Once:
  mini-client\install-gsi.bat
  Steam Dota launch option: -gamestateintegration
  mini-client\open-overwolf-app.bat -> Load unpacked in Overwolf

Delete old folders: ReplayFace-MiniClient and ReplayFace-MiniClient (1)
